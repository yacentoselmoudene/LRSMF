from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('parametrage/', views.parametres, name='parametres'),
    path('addaction/', views.addAction_vue, name='AddAction'),
    path('addassociation/', views.addAssociation_vue, name='addassociation'),
]
