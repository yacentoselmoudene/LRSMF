from django.shortcuts import render, redirect
from django.http import JsonResponse
from . import models

selectedType = 'saison_sportif'
extraSelect = None

def home(request):
    return render(request, 'index.html')

def addAction_vue(request):
    bigData = getAllData()
    return render(request, 'ajout_action.html', {'bigData': bigData})

def parametres(request):
    global selectedType
    global extraSelect
    if request.method == "POST":
        selectedType = request.POST.get('type')
        if str(selectedType) in ['entrainneur', 'responsable_action']:
            firstName = request.POST.get('firstName')
            lastName = request.POST.get('lastName')
            birthDate = request.POST.get('birthDate')
            data = {'firstName':firstName, 'lastName':lastName, 'birthDate':birthDate}
            addToDb(selectedType, data)
        else:
            decription = request.POST.get('decription')
            extraSelectValue = request.POST.get('extraSelect')
            data = {'extraSelectValue':extraSelectValue, 'value':decription}
            addToDb(selectedType, data)

    bigData = getAllData()
    
    if selectedType == 'province':
        extraSelect = list(bigData['region'])
    elif selectedType == 'commune':
        extraSelect = list(bigData['province'])

    return render(request, 'parametrage.html', {'selectedType':selectedType, 'bigData': bigData, 'extraSelect':extraSelect})

def getAllData():
    bigData = {
                'saison_sportif':models.ModeleSaison.objects.values().all(), 
                'pole_sportif':models.ModelePole.objects.values().all(), 
                'region':models.ModeleRegion.objects.values().all(), 
                'province':models.ModeleProvince.objects.values().all(), 
                'commune':models.ModeleCommune.objects.values().all(), 
                'entrainneur':models.Entrainneur.objects.values().all(), 
                'responsable_action':models.ResponsableAction.objects.values().all(),  
            }
    for key, queryset in bigData.items():
        data = list(queryset.values())
        bigData[key] = data
    return bigData

def addToDb(dataBase, data):
    if str(dataBase) == 'saison_sportif':
        db = models.ModeleSaison()
        db.description = data['value']
    elif str(dataBase) == 'pole_sportif':
        db = models.ModelePole()
        db.description = data['value']
    elif str(dataBase) == 'region':
        db = models.ModeleRegion()
        db.description = data['value']
    elif str(dataBase) == 'province':
        db = models.ModeleProvince()
        db.description = data['value']
        db.region = data['extraSelectValue']
    elif str(dataBase) == 'commune':
        db = models.ModeleCommune()
        db.description = data['value']
        db.province = data['extraSelectValue']
    elif str(dataBase) == 'entrainneur':
        db = models.Entrainneur()
        db.nom = data['firstName']
        db.prenom = data['lastName']
        db.date_naissance = data['birthDate']
    elif str(dataBase) == 'responsable_action':
        db = models.ResponsableAction()
        db.nom = data['firstName']
        db.prenom = data['lastName']
        db.date_naissance = data['birthDate']
    db.save()

def addAssociation_vue(request):
    return JsonResponse({})