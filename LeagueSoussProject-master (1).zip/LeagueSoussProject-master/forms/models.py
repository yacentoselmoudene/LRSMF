from django.db import models

class ModeleSaison(models.Model):
    description = models.CharField(max_length=255)
    def __str__(self):
        return self.description

class ModelePole(models.Model):
    description = models.CharField(max_length=255)
    def __str__(self):
        return self.description

class ModeleRegion(models.Model):
    description = models.CharField(max_length=255)
    def __str__(self):
        return self.description

class ModeleProvince(models.Model):
    region = models.CharField(max_length=255, null=True, blank=True)
    description = models.CharField(max_length=255)
    def __str__(self):
        return self.description
    
class ModeleCommune(models.Model):
    province = models.CharField(max_length=255, null=True, blank=True)
    description = models.CharField(max_length=255)
    def __str__(self):
        return self.description

class personne(models.Model):
    nom = models.CharField(max_length=255)
    prenom = models.CharField(max_length=255)
    date_naissance = models.CharField(max_length=255)
        
class Entrainneur(models.Model) :
    nom = models.CharField(max_length=255)
    prenom = models.CharField(max_length=255)
    date_naissance = models.CharField(max_length=255)
        
class Arbitre(models.Model) :
    nom = models.CharField(max_length=255)
    prenom = models.CharField(max_length=255)
    date_naissance = models.CharField(max_length=255)

class Joueur(models.Model) :
    nom = models.CharField(max_length=255)
    prenom = models.CharField(max_length=255)
    date_naissance = models.CharField(max_length=255)

class Delegue(models.Model) :
    nom = models.CharField(max_length=255)
    prenom = models.CharField(max_length=255)
    date_naissance = models.CharField(max_length=255)

class Stagiaire(models.Model) :
    nom = models.CharField(max_length=255)
    prenom = models.CharField(max_length=255)
    date_naissance = models.CharField(max_length=255)

class ResponsableAction(models.Model) :
    nom = models.CharField(max_length=255)
    prenom = models.CharField(max_length=255)
    date_naissance = models.CharField(max_length=255)

class ResponsableProgramation(models.Model) :
    nom = models.CharField(max_length=255)
    prenom = models.CharField(max_length=255)
    date_naissance = models.CharField(max_length=255)
