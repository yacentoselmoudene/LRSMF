from django.contrib import admin
from . import models

admin.site.register(models.ModeleCommune)
admin.site.register(models.ModelePole)
admin.site.register(models.ModeleProvince)
admin.site.register(models.ModeleRegion)
admin.site.register(models.ModeleSaison)


admin.site.register(models.Entrainneur)
admin.site.register(models.Arbitre)
admin.site.register(models.Joueur)
admin.site.register(models.Delegue)
admin.site.register(models.Stagiaire)